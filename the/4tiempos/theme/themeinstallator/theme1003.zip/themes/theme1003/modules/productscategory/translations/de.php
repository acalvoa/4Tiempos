<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productscategory}prestashop>productscategory_d4647e3ff0ce2748179d79283d78efe4'] = 'Block Produktkategorie';
$_MODULE['<{productscategory}prestashop>productscategory_f27f804206002ccd80c81c3841603b1a'] = 'Zeigt Produkte der gleichen Kategorie auf der Produktseite an.';
$_MODULE['<{productscategory}prestashop>productscategory_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{productscategory}prestashop>productscategory_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{productscategory}prestashop>productscategory_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{productscategory}prestashop>productscategory_4aae87211f77aada2c87907121576cfe'] = 'andere Produkte der gleichen Kategorie:';
$_MODULE['<{productscategory}prestashop>productscategory_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Weiter';


return $_MODULE;
