<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklink}prestashop>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Block Links';
$_MODULE['<{blocklink}prestashop>blocklink_baa2ae9622a47c3217d725d1537e5187'] = 'Fügt einen Block mit zusätzlichen Links hinzu';
$_MODULE['<{blocklink}prestashop>blocklink_8d85948ef8fda09c2100de886e8663e5'] = 'Sind Sie sicher, dass Sie alle Ihre Links löschen wollen?';
$_MODULE['<{blocklink}prestashop>blocklink_666f6333e43c215212b916fef3d94af0'] = 'Sie müssen alle Felder ausfüllen.';
$_MODULE['<{blocklink}prestashop>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'Falsche URL';
$_MODULE['<{blocklink}prestashop>blocklink_3da9d5745155a430aac6d7de3b6de0c8'] = 'Link wurde erfolgreich hinzugefügt';
$_MODULE['<{blocklink}prestashop>blocklink_898536ebd630aa3a9844e9cd9d1ebb9b'] = 'Bei der Link-Erstellung iste ein Fehler aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_b18032737875f7947443c98824103a1f'] = 'Das Feld "Name" darf nicht leer bleiben';
$_MODULE['<{blocklink}prestashop>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'Das Feld "Name" ist ungültig';
$_MODULE['<{blocklink}prestashop>blocklink_eb74914f2759760be5c0a48f699f8541'] = 'Bei der Aktualisierung des Namens ist ein Fehler aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_5c0f7e2db8843204f422a369f2030b37'] = 'Blockname wurde aktualisiert';
$_MODULE['<{blocklink}prestashop>blocklink_5d73d4c0bcb035a1405e066eb0cdf832'] = 'Beim Löschen des Links  ist ein Fehler aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_9bbcafcc85be214aaff76dffb8b72ce9'] = 'Der Link ist erfolgreich gelöscht worden';
$_MODULE['<{blocklink}prestashop>blocklink_7e5748d8c44f33c9cde08ac2805e5621'] = 'Sortierung aktualisiert';
$_MODULE['<{blocklink}prestashop>blocklink_46cff2568b00bc09d66844849d0b1309'] = 'Bei der Aktualisierung der Sortierung ist ein Fehler aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Neuen Link hinzufügen';
$_MODULE['<{blocklink}prestashop>blocklink_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Text';
$_MODULE['<{blocklink}prestashop>blocklink_3b3d06023f6353f8fd05f859b298573e'] = 'URL:';
$_MODULE['<{blocklink}prestashop>blocklink_1f3674ab0d54a38327e8e4a0d97788d4'] = 'In neuem Fenster öffnen:';
$_MODULE['<{blocklink}prestashop>blocklink_f16b5952df8d25ea30b25ff95ee8fedf'] = 'Shop-Zugehörigkeit:';
$_MODULE['<{blocklink}prestashop>blocklink_7f3ee1818e42cfd668e361d89b8595fb'] = 'Diesen Link hinzufügen';
$_MODULE['<{blocklink}prestashop>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Block-Name';
$_MODULE['<{blocklink}prestashop>blocklink_2c906769e7f8b03cc1fedce4e24a20c2'] = 'Block-Name:';
$_MODULE['<{blocklink}prestashop>blocklink_67c94c1cba852f2d13eed115c938baf6'] = 'Block-URL:';
$_MODULE['<{blocklink}prestashop>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Aktualisierung';
$_MODULE['<{blocklink}prestashop>blocklink_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocklink}prestashop>blocklink_9b9d1ed2e377a28925de723d1d300e91'] = 'Sortierung';
$_MODULE['<{blocklink}prestashop>blocklink_704b746de8f87e82d5193ceb523d872a'] = 'neueste Links';
$_MODULE['<{blocklink}prestashop>blocklink_027434466fc0739d79a00730024657a1'] = 'älteste links';
$_MODULE['<{blocklink}prestashop>blocklink_490aa6e856ccf208a054389e47ce0d06'] = 'ID';
$_MODULE['<{blocklink}prestashop>blocklink_02a3a357710cc2a5dfdfb74ed012fb59'] = 'URL';
$_MODULE['<{blocklink}prestashop>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Link-Liste';
$_MODULE['<{blocklink}prestashop>blocklink_e124f0a8a383171357b9614a45349fb5'] = 'In neuem Fenster öffnen';
$_MODULE['<{blocklink}prestashop>blocklink_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blocklink}prestashop>blocklink_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blocklink}prestashop>blocklink_9d55fc80bbb875322aa67fd22fc98469'] = 'Shop-Zugehörigkeit.';
$_MODULE['<{blocklink}prestashop>blocklink_861dc984a1e9aa1e7fef283b4886c2b6'] = 'Einen neuen Block hinzufügen';
$_MODULE['<{blocklink}prestashop>blocklink_aed3f8ab8adeac5f8a45a3a675cff941'] = 'Sortierung';
$_MODULE['<{blocklink}prestashop>blocklink_d36e9f57ea37903f81d28f7a189b9649'] = 'nach neuesten Links';
$_MODULE['<{blocklink}prestashop>blocklink_6ccdff04699ffe6956a6b1465907414a'] = 'nach ältesten Links';


return $_MODULE;
