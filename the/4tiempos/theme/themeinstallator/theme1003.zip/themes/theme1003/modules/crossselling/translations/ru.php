<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{crossselling}prestashop>crossselling_462390017ab0938911d2d4e964c0cab7'] = 'Настройки успешно обновлены';
$_MODULE['<{crossselling}prestashop>crossselling_b6bf131edd323320bac67303a3f4de8a'] = 'Отображать цену товаров';
$_MODULE['<{crossselling}prestashop>crossselling_70f9a895dc3273d34a7f6d14642708ec'] = 'Отображать цену товаров в блоке.';


return $_MODULE;
