<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{referralprogram}prestashop>referralprogram_6b31baf25848e7a6563ecc3946626c80'] = 'Реферальная программа';
$_MODULE['<{referralprogram}prestashop>referralprogram_22ffd0379431f3b615eb8292f6c31d12'] = 'Дата регистрации';
$_MODULE['<{referralprogram}prestashop>referralprogram_37be07209f53a5d636d5c904ca9ae64c'] = 'Процент';
$_MODULE['<{referralprogram}prestashop>referralprogram_6b719c160f9b08dad4760bcc4b52ed48'] = 'Условия реферальной программы';
$_MODULE['<{referralprogram}prestashop>form_386c339d37e737a436499d423a77df0c'] = 'Валюта';
$_MODULE['<{referralprogram}prestashop>program_d3d2e617335f08df83599665eef8a418'] = 'Закрыть';
$_MODULE['<{referralprogram}prestashop>program_7a81aa9275331bb0f5e6adb5e8650a03'] = 'или клавиша Esc';
$_MODULE['<{referralprogram}prestashop>program_dbc65cd60abde51277c2881ce915a225'] = 'Вы должны принять условия реферальной программы';
$_MODULE['<{referralprogram}prestashop>program_83fc792f687bc45d75ac35c84c721a26'] = 'По крайней мере один адрес не верный!';
$_MODULE['<{referralprogram}prestashop>program_1019072b9e450c8652590cda2db45e49'] = 'Имя или фамилия не верные!';
$_MODULE['<{referralprogram}prestashop>program_ff2d2e45b90b4426c3bb14bd56b95a2d'] = 'Кто-то, с этим адресом уже имеет спонсора!';
$_MODULE['<{referralprogram}prestashop>program_3f8a4c7f93945fea0d951fa402ee4272'] = 'Пожалуйста, поставьте хотя бы одну отметку';
$_MODULE['<{referralprogram}prestashop>program_dcc99d8715486f570db3ec5ee469a828'] = 'Невозможно добавить друзей в базу данных';
$_MODULE['<{referralprogram}prestashop>program_f6cb78f0afcf7c3a06048a7a5855d6a1'] = 'Сообщения электронной почты были отправлены Вашим друзьям!';
$_MODULE['<{referralprogram}prestashop>program_79cd362fc64832faa0a2079f1142aa12'] = 'Сообщения электронной почты были отправлены Вашему другу!';
$_MODULE['<{referralprogram}prestashop>program_2b90ca4a7b1c83e0a3bb65899725cd65'] = 'Электронные письма с напоминанием были отправлены друзьям!';
$_MODULE['<{referralprogram}prestashop>program_819e52b3c6ca4db131dcfea19188a0c3'] = 'Электронные письма с напоминанием были отправлены другу!';
$_MODULE['<{referralprogram}prestashop>program_46ee2fe8845962d24bf5178a26e109f3'] = 'Отправить друзьям';
$_MODULE['<{referralprogram}prestashop>program_7e9b0e998138fefac8749975c737ac27'] = 'Отправить друзьям';
$_MODULE['<{referralprogram}prestashop>program_c56567bc42584de1a7ac430039b3a87e'] = 'Рефералы друзей';
$_MODULE['<{referralprogram}prestashop>program_b9ebe5bbe91ed6e7e23285fb6c595ab4'] = 'Я приглашаю друзей';
$_MODULE['<{referralprogram}prestashop>program_58c7f2542ab2e2c3e4e39e851ea0f225'] = 'Я реферал у';
$_MODULE['<{referralprogram}prestashop>program_8d3ae82bfa996855cdf841dd9e15a7e3'] = 'Это легко и быстро. Просто укажите имя, фамилию, и e-mail адрес(а) друга(друзей) в поле ниже.';
$_MODULE['<{referralprogram}prestashop>program_c92182a305ac874bae5e54d75bbd9327'] = 'Когда один из них сделает хотя-бы %d заказов';
$_MODULE['<{referralprogram}prestashop>program_6e8dedb6b5dcad23e24d07c10aff29d8'] = 'Когда один из них сделает хотя-бы %d заказ';
$_MODULE['<{referralprogram}prestashop>program_9386de858384e7f790a28beecdb986dd'] = 'Важно: E-mail адреса ваших друзей будут использоваться только в реферальной программе. И никогда для других целей.';
$_MODULE['<{referralprogram}prestashop>program_605eef3cad421619ce034ab48415190f'] = 'Я согласен с условиями службы и присоединения к ним безоговорочно.';
$_MODULE['<{referralprogram}prestashop>program_868ca5fe643791c23b47c75fb833c9b8'] = 'Прочитать условия.';
$_MODULE['<{referralprogram}prestashop>program_31fde7b05ac8952dacf4af8a704074ec'] = 'Предпросмотр';
$_MODULE['<{referralprogram}prestashop>program_8e8dc296c6bf3876468aa028974bfebe'] = 'Пригласительный e-mail';
$_MODULE['<{referralprogram}prestashop>program_a86073a0c3b0bebf11bd807caf8e505a'] = 'e-mail по умолчанию';
$_MODULE['<{referralprogram}prestashop>program_7532696b81dfc0b94a37e876677152c5'] = ', который будет отправлен Вашему другу/друзьям.';
$_MODULE['<{referralprogram}prestashop>program_ad3d06d03d94223fa652babc913de686'] = 'Сохранить';
$_MODULE['<{referralprogram}prestashop>program_59352cd5314a67c0fb10c964831920f3'] = 'Чтобы участвовать в программе нужен хотя бы';
$_MODULE['<{referralprogram}prestashop>program_12c500ed0b7879105fb46af0f246be87'] = 'Заказы';
$_MODULE['<{referralprogram}prestashop>program_70a17ffa722a3985b86d30b034ad06d7'] = 'заказ';
$_MODULE['<{referralprogram}prestashop>program_ec7342814444c667ab93181b30b28e38'] = 'Со времени вашего спонсирования друзей, они не делали заказов, но вы ожете попытаться еще раз! Чтобы сделать это, поставьте отметки напротив тех друзей, которым вы хотите напомнить и нажмите кнопку "Напомнить друзьям"';
$_MODULE['<{referralprogram}prestashop>program_3e717a04ff77cd5fa068d8ad9d3facc8'] = 'Последнее приглашение';
$_MODULE['<{referralprogram}prestashop>program_9c9d4ed270f02c72124702edb192ff19'] = 'Напомнить друзьям';
$_MODULE['<{referralprogram}prestashop>program_8b9f390369560635a2ba5ba271d953df'] = 'Нет';
$_MODULE['<{referralprogram}prestashop>program_193f3d8bbaceba40499cab1a3545e9e8'] = 'Сдесь показаны друзья, спонсированные вами и принявшие приглашение:';
$_MODULE['<{referralprogram}prestashop>program_3c648ba41cfb45f13b083a9cbbacdfdf'] = 'Дата выписки';
$_MODULE['<{referralprogram}prestashop>program_8d4e5c2bc4c3cf67d2b59b263a707cb6'] = 'Приглашений не принято';
$_MODULE['<{referralprogram}prestashop>rules_01705c0177ebf5fbcbf4e882bc454405'] = 'Правила реферальной программы';
$_MODULE['<{referralprogram}prestashop>authentication_8fdb2298a0db461ac64e71192a562ca1'] = 'E-mail адрес вашего спонсора';
$_MODULE['<{referralprogram}prestashop>order-confirmation_f2ef523efa8d23f8afc29e195592fc58'] = 'Спасибо за ваш заказ, ваш поручитель %1$s %2$s получит купон с %3$d  скидкой после подтверждения вашего заказа.';
$_MODULE['<{referralprogram}prestashop>shopping-cart_b76b807810393d9fce7f154d82aef1d1'] = 'Благодаря вашему поручителю вы получили купон со скидкой %s!';
$_MODULE['<{referralprogram}prestashop>shopping-cart_9a5b602be8d9b2d4b8c3f22911fba01d'] = 'Введите имя купона %s для получения скидки на этот товар.';
$_MODULE['<{referralprogram}prestashop>shopping-cart_106527986549f3ec8da1ae5a7abde467'] = 'Просмотреть свою реферальную программу.';


return $_MODULE;
