<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_9e31b08a00c1ed653bcaa517dee84714'] = 'Block Newsletter';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_ba457fab18d697d978befb95e827eb91'] = 'Fügt einen Block für Newsletter-Abos hinzu';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_396c88991101b5ca362932952293d291'] = 'Sind Sie sicher, dass Sie alle Kontakte löschen wollen?';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_417d63b1effb110e438d4b4b9f0fbd95'] = 'Gutschein-Code ungültig';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_e267e2be02cf3e29f4ba53b5d97cf78a'] = 'Ungültige E-Mail-Adresse';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_1c623b291d95f4f1b1d0c03d0dc0ffa1'] = 'E-Mail-Adresse nicht registriert';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_3b1f17a6fd92e35bc744e986b8e7a61c'] = 'Fehler bei der Abo-Abmeldung';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_d4197f3e8e8b4b5d06b599bc45d683bb'] = 'Abo-Abmeldung erfolgreich.';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_f6618fce0acbfca15e1f2b0991ddbcd0'] = 'E-Mail-Adresse bereits registriert';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_e172cb581e84f43a3bd8ee4e3b512197'] = 'Fehler beim Abonnement';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_ebc069b1b9a2c48edfa39e344103be1e'] = 'Wir haben Ihnen eine Bestätigungs-E-Mail zugesandt. Bitte prüfen Sie Ihr E-Mail-Postfach.';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_77c576a354d5d6f5e2c1ba50167addf8'] = 'Abonnement erfolgreich';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_99c8b8e5e51bf8f00f1d66820684be9a'] = 'Diese E-Mail ist bereits registriert oder ungültig.';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_4e1c51e233f1ed368c58db9ef09010ba'] = 'Vielen Dank für Ihre Anmeldung zu unserem newsletter.';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_54d2f1bab16b550e32395a7e6edb8de5'] = 'Nach Newsletter-Anmeldung Verifizierung-Mail versenden?';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_93cba07454f06a4a960172bbd6e2a435'] = 'Ja';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nein';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_b37f32d509cf5aabe806b16791588aa3'] = 'Bestätigungsmail nach Abonnement senden?';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_506e58042922bff5bd753dc612e84f5b'] = 'Willkommensgutschein-Code';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_1d612b943b8f4792bff603384a46e5f1'] = 'Zur Deaktivierung leer lassen';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Newsletter';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_416f61a2ce16586f8289d41117a2554e'] = 'Ihre E-Mail';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_d8335f4a5d918134bd0bdc47cc487d74'] = 'Geben Sie Ihre E-Mail-Adresse ein';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_a60852f204ed8028c1c58808b746d115'] = 'OK';
$_MODULE['<{blocknewsletter}prestashop>blocknewsletter_590b7aefc83952e3483c5168bf93e19f'] = 'Newsletter : %1$s';


return $_MODULE;
