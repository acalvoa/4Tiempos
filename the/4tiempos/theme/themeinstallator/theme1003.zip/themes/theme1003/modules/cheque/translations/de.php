<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{cheque}prestashop>cheque_7b4cc4f79be9aae43efd53b4ae5cba4d'] = 'Scheckzahlung';
$_MODULE['<{cheque}prestashop>cheque_14e41f4cfd99b10766cc15676d8cda66'] = 'Modul Zahlung per Scheck';
$_MODULE['<{cheque}prestashop>cheque_e09484ba6c16bc20236b63cc0d87ee95'] = 'Möchten Sie wirklich die Details löschen?';
$_MODULE['<{cheque}prestashop>cheque_32776feb26ff6f9648054e796aa0e423'] = '"Scheckzahlung" und Adressinformationen müssen eingerichtet sein, um dieses Modul richtig zu nutzen.';
$_MODULE['<{cheque}prestashop>cheque_81c6c3ba23ca2657a8eedc561f865ddb'] = '"Zahlungsempfänger" ist ein Pflichtfeld.';
$_MODULE['<{cheque}prestashop>cheque_00a369029140cfd18857425d49b472f8'] = '"Adresse" ist ein Pflichtfeld.';
$_MODULE['<{cheque}prestashop>cheque_5dd532f0a63d89c5af0243b74732f63c'] = 'Kontaktangaben';
$_MODULE['<{cheque}prestashop>cheque_4b2f62e281e9a6829c6df0e87d34233a'] = 'Zahlungsempfänger (Name)';
$_MODULE['<{cheque}prestashop>cheque_0fe62049ad5246bc188ec1bae347269e'] = 'Anschrift, an die der Scheck geschickt werden soll';
$_MODULE['<{cheque}prestashop>cheque_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{cheque}prestashop>payment_execution_8520b283b0884394b13b80d5689628b3'] = 'Scheckzahlung';
$_MODULE['<{cheque}prestashop>payment_execution_060bf2d587991d8f090a1309b285291c'] = 'Scheck';
$_MODULE['<{cheque}prestashop>payment_execution_76ca011e4772bfcce26aecd42c598510'] = 'Sie haben die Bezahlung per Scheck gewählt.';
$_MODULE['<{cheque}prestashop>payment_execution_3b3b41f131194e747489ef93e778ed0d'] = 'Der Gesamtbetrag Ihrer Bestellung beträgt';
$_MODULE['<{cheque}prestashop>payment_execution_1f87346a16cf80c372065de3c54c86d9'] = '(inkl. MwSt.)';
$_MODULE['<{cheque}prestashop>payment_execution_7b1c6e78d93817f61f2b1bbc2108a803'] = 'Wir akzeptieren mehrere Währungen bei Scheckzahlungen.';
$_MODULE['<{cheque}prestashop>payment_execution_f73ad0f08052884ff465749bf48b55ce'] = 'Wir akzeptieren für Scheckzahlung die folgende Währung:';
$_MODULE['<{cheque}prestashop>payment_execution_7135ff14c7931e1c8e9d33aff3dfc7f7'] = 'Scheckinhaber und Adressinformationen werden auf der nächsten Seite angezeigt.';
$_MODULE['<{cheque}prestashop>infos_e444fe40d43bccfad255cf62ddc8d18f'] = 'Wählt der Kunde diese Zahlungsart, wechselt der Auftragsstatus zu "Warte auf Zahlung".';
$_MODULE['<{cheque}prestashop>infos_8c88bbf5712292b26e2a6bbeb0a7b5c4'] = 'Sie müssen die Bestellung manuell bestätigen, sobald Sie einen Scheck erhalten.';
$_MODULE['<{cheque}prestashop>payment_return_61da27a5dd1f8ced46c77b0feaa9e159'] = 'Bitte senden Sie uns einen Scheck über:';
$_MODULE['<{cheque}prestashop>payment_return_621455d95c5de701e05900a98aaa9c66'] = 'Zahlungsbetrag';
$_MODULE['<{cheque}prestashop>payment_return_9b8f932b1412d130ece5045ecafd1b42'] = 'zahlbar an';
$_MODULE['<{cheque}prestashop>payment_return_9a94f1d749a3de5d299674d6c685e416'] = 'E-Mail an';
$_MODULE['<{cheque}prestashop>payment_return_e1c54fdba2544646684f41ace03b5fda'] = 'Bitte vergessen Sie nicht, Ihre Bestellnummer #%d mit anzugeben.';
$_MODULE['<{cheque}prestashop>payment_return_4761b03b53bc2b3bd948bb7443a26f31'] = 'Bitte vergessen Sie nicht, Ihre Bestellnummer %s mit anzugeben.';
$_MODULE['<{cheque}prestashop>payment_return_610abe74e72f00210e3dcb91a0a3f717'] = 'Eine E-Mail mit diesen Informationen wurde Ihnen zugesandt.';
$_MODULE['<{cheque}prestashop>payment_return_ffd2478830ca2f519f7fe7ee259d4b96'] = 'Sie erhalten Ihre Bestellung, sobald die Zahlung eingegangen ist.';
$_MODULE['<{cheque}prestashop>payment_return_decce112a9e64363c997b04aa71b7cb8'] = 'Kunden-Support';
$_MODULE['<{cheque}prestashop>payment_return_9bdf695c5a30784327137011da6ef568'] = 'Wir haben bei Ihrer Bestellung ein Problem festgestellt. Wenn Sie denken, dies sei ein Fehler, können Sie an unseren';
$_MODULE['<{cheque}prestashop>payment_f05fd8637f8a6281466a507fcb56baec'] = 'Zahlung per Scheck';
$_MODULE['<{cheque}prestashop>payment_4b80fae2153218ed763bdadc418e8589'] = 'Zahlung per Scheck';


return $_MODULE;
