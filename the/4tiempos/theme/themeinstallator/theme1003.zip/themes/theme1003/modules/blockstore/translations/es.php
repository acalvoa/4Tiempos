<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockstore}prestashop>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Bloque tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_c1104fe0bdaceb2e1c6f77b04977b64b'] = 'Muestra un enlace a la imagen característica de localización de tiendas de PrestaShop.';
$_MODULE['<{blockstore}prestashop>blockstore_7107f6f679c8d8b21ef6fce56fef4b93'] = 'imagen no válida.';
$_MODULE['<{blockstore}prestashop>blockstore_616f723a17ccb34e38aa6e1ddc1c0b47'] = '(La imagen seleccionada se mostrará como 174 píxeles por 115 píxeles).';
$_MODULE['<{blockstore}prestashop>blockstore_8c0caec5616160618b362bcd4427d97b'] = '¡Nuestra(s) tienda(s)!';
$_MODULE['<{blockstore}prestashop>blockstore_28fe12f949fd191685071517628df9b3'] = 'Descubra nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Nuestras tiendas';
$_MODULE['<{blockstore}prestashop>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Descubra nuestras tiendas';


return $_MODULE;
