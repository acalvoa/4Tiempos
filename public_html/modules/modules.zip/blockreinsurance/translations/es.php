<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_873330fc1881555fffe2bc471d04bf5d'] = 'Bloque de reaseguros';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_7e7f70db3c75e428db8e2d0a1765c4e9'] = 'Añadir un bloque para ver más informaciones para tranquilizar a sus clientes';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_d52eaeff31af37a4a7e0550008aff5df'] = 'Se produjo un error durante el guardado.';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'Configuración actualizada';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_8363eee01f4da190a4cef9d26a36750c'] = 'Nuevo bloque de reaseguro';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imagen';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Textos';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_23498d91b6017e5d7f4ddde70daba286'] = 'ID tienda';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_ef61fb324d729c341ea8ab9901e23566'] = 'Añadir nuevo';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_f3295a93167b56c5a19030e91823f7bf'] = 'Reembolso de dinero';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_56e140ebd6f399c22c8859a694b247f3'] = 'Cambio en tienda';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_597ce11744f9bbf116ec9e4a719ec9d3'] = 'Pago después del recibo';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_3aca7ac5cf7e462b658960931946f824'] = 'Transportista gratuito';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_d05244e0e410a6b85ed53a014908c657'] = 'Pago asegurado al 100%';


return $_MODULE;
