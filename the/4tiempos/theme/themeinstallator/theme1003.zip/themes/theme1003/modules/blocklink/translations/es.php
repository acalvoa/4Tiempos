<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklink}prestashop>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Bloque de enlaces';
$_MODULE['<{blocklink}prestashop>blocklink_baa2ae9622a47c3217d725d1537e5187'] = 'Añadir un bloque con enlaces adicionales';
$_MODULE['<{blocklink}prestashop>blocklink_8d85948ef8fda09c2100de886e8663e5'] = '¿Seguro que quieres borrar todos tus enlaces?';
$_MODULE['<{blocklink}prestashop>blocklink_666f6333e43c215212b916fef3d94af0'] = 'Debe rellenar todos los campos.';
$_MODULE['<{blocklink}prestashop>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'URL incorrecta';
$_MODULE['<{blocklink}prestashop>blocklink_3da9d5745155a430aac6d7de3b6de0c8'] = 'En enlace se ha añadido con éxito';
$_MODULE['<{blocklink}prestashop>blocklink_898536ebd630aa3a9844e9cd9d1ebb9b'] = 'Se ha producido un error durante el proceso de creación del enlace';
$_MODULE['<{blocklink}prestashop>blocklink_b18032737875f7947443c98824103a1f'] = 'El campo "título" no puede estar vacío';
$_MODULE['<{blocklink}prestashop>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'El campo \\"título\\" es incorrecto';
$_MODULE['<{blocklink}prestashop>blocklink_eb74914f2759760be5c0a48f699f8541'] = 'Se ha producido un error durante la actualización del título';
$_MODULE['<{blocklink}prestashop>blocklink_5c0f7e2db8843204f422a369f2030b37'] = 'El título del bloque se ha actualizado con éxito';
$_MODULE['<{blocklink}prestashop>blocklink_5d73d4c0bcb035a1405e066eb0cdf832'] = 'Se ha producido un error mientras se borraba el enlace';
$_MODULE['<{blocklink}prestashop>blocklink_9bbcafcc85be214aaff76dffb8b72ce9'] = 'El enlace se ha eliminado correctamente';
$_MODULE['<{blocklink}prestashop>blocklink_7e5748d8c44f33c9cde08ac2805e5621'] = 'Actualización correcta de la reordenación';
$_MODULE['<{blocklink}prestashop>blocklink_46cff2568b00bc09d66844849d0b1309'] = 'Se ha producido un error durante el proceso de configuración de la reordenación';
$_MODULE['<{blocklink}prestashop>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Añadir un nuevo enlace';
$_MODULE['<{blocklink}prestashop>blocklink_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Texto:';
$_MODULE['<{blocklink}prestashop>blocklink_3b3d06023f6353f8fd05f859b298573e'] = 'URL:';
$_MODULE['<{blocklink}prestashop>blocklink_1f3674ab0d54a38327e8e4a0d97788d4'] = 'Abrir en una nueva ventana:';
$_MODULE['<{blocklink}prestashop>blocklink_f16b5952df8d25ea30b25ff95ee8fedf'] = 'Asociación de tienda';
$_MODULE['<{blocklink}prestashop>blocklink_7f3ee1818e42cfd668e361d89b8595fb'] = 'A~ãdir este enlace';
$_MODULE['<{blocklink}prestashop>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Título del bloque';
$_MODULE['<{blocklink}prestashop>blocklink_2c906769e7f8b03cc1fedce4e24a20c2'] = 'Título del bloque:';
$_MODULE['<{blocklink}prestashop>blocklink_67c94c1cba852f2d13eed115c938baf6'] = 'URL del bloque:';
$_MODULE['<{blocklink}prestashop>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Actualizar';
$_MODULE['<{blocklink}prestashop>blocklink_9b9d1ed2e377a28925de723d1d300e91'] = 'Ordenar lista por:';
$_MODULE['<{blocklink}prestashop>blocklink_704b746de8f87e82d5193ceb523d872a'] = 'enlaces más recientes';
$_MODULE['<{blocklink}prestashop>blocklink_027434466fc0739d79a00730024657a1'] = 'enlaces más viejos';
$_MODULE['<{blocklink}prestashop>blocklink_490aa6e856ccf208a054389e47ce0d06'] = 'Id';
$_MODULE['<{blocklink}prestashop>blocklink_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Textos';
$_MODULE['<{blocklink}prestashop>blocklink_02a3a357710cc2a5dfdfb74ed012fb59'] = 'URL:';
$_MODULE['<{blocklink}prestashop>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Lista de enlaces';
$_MODULE['<{blocklink}prestashop>blocklink_e124f0a8a383171357b9614a45349fb5'] = 'Abrir en una ventana nueva';
$_MODULE['<{blocklink}prestashop>blocklink_9d55fc80bbb875322aa67fd22fc98469'] = 'Asociación de tienda';
$_MODULE['<{blocklink}prestashop>blocklink_861dc984a1e9aa1e7fef283b4886c2b6'] = 'Añadir un bloque nuevo';
$_MODULE['<{blocklink}prestashop>blocklink_aed3f8ab8adeac5f8a45a3a675cff941'] = 'Lista del pedido';
$_MODULE['<{blocklink}prestashop>blocklink_d36e9f57ea37903f81d28f7a189b9649'] = 'por enlaces más recientes';
$_MODULE['<{blocklink}prestashop>blocklink_6ccdff04699ffe6956a6b1465907414a'] = 'por enlaces más antiguos';


return $_MODULE;
