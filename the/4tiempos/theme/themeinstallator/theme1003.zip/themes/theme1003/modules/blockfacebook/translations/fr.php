<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockfacebook}prestashop>blockfacebook_06d770829707bb481258791ca979bd2a'] = 'Bloc Facebook';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_f66e16efd2f1f43944e835aa527f9da8'] = 'Affiche un bloc pour s\'inscrire à votre page Facebook.';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_5a67f55ebe6b8e4056f9c285fa762d70'] = 'Nom du compte Facebook';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_a4aa9244ea53b5d916dfd8f024d11e22'] = 'Suivez-nous sur Facebook!';


return $_MODULE;
