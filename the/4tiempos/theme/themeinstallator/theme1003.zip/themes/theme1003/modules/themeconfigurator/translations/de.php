<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Template-Konfigurator';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_cf8fdaf6e745133c90516eb9b74e31c3'] = 'Richten Sie die Elemente Ihres Templates ein.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_eedb7e9e8a884cb0a78a55528e8b8fab'] = 'Mehr als 500 PrestaShop Premium-Templates! Jetzt sofort durchsehen!';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_149cd107b688af7a007e739fd51ac919'] = 'Löschen erfolgreich';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_ec870aa68b135c4f3adc9a3a2731ddbc'] = 'Slide kann nicht gelöscht werden.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_3ee0c881516fce384747e3107dbfc538'] = 'Ungültiger Inhalt';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_dd2681ec1593dd537587be3389ee24d3'] = 'Beim Speichern ist ein Fehler aufgetreten.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_b9099a0a16c40efc8b73f548144d472f'] = 'Update erfolgreich';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Beim Bild-Upload ist ein Fehler aufgetreten.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_dccadfc1bf4714d72add6b2332505009'] = 'Neue Elemente erfolgreich hinzugefügt';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f1206f9fadc5ce41694f69129aecac26'] = 'Konfigurieren';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_6e3670bb5e3826106c5243b242cc52d9'] = 'Links zu Ihren Accounts (Shop) in Sozialen Netzwerken (Twitter, Facebook, usw.)';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_4bae4cdd2d56a5a8b8c320288c5d3426'] = 'Kontaktinformationen anzeigen';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_17a84b9793933f127b961f44b9c8bcbc'] = 'Buttons sozialer Netzwerke auf Produktseite anzeigen';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_6080ab31226b39af728c2d40fd57f0d0'] = 'Block Facebook auf der Homepage anzeigen';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_87965e506665f83903c1de5d3ad0c98e'] = 'Schnellanzeige aktivieren';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_158fc4b90f7acab3770c57827fb0e424'] = 'Bannerleiste aktivieren';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_cf5ca43ed94712fe0160fff0a523b8ef'] = 'Zahlungslogos anzeigen';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_2e1328793a14abff890f7bae4234328c'] = 'Template-Konfigurator aktivieren';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'Mit dem Anpassungs-Tool können Sie Farbe und Schriftart ihres Templates ändern.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_b952538cab3142a26ac46f8da619e2f9'] = '%s wird nur Ihnen angezeigt - Ihre Besucher sehen dieses Tool nicht.';
$_MODULE['<{themeconfigurator}prestashop>items_b9b371458ab7c314f88b81c553f6ce51'] = 'Andockpunkt (Hook)';
$_MODULE['<{themeconfigurator}prestashop>items_e8cf85cec621489ec026f7e06c67eb4e'] = 'Element löschen';
$_MODULE['<{themeconfigurator}prestashop>items_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Bildbreite';
$_MODULE['<{themeconfigurator}prestashop>items_21de26caa6bcfc936378c4e45d235bd9'] = 'px';
$_MODULE['<{themeconfigurator}prestashop>items_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Bildhöhe';
$_MODULE['<{themeconfigurator}prestashop>items_4c87eb073eb09f42281d7e67aeacb223'] = 'Target blank';
$_MODULE['<{themeconfigurator}prestashop>items_4c4ad5fca2e7a3f74dbb1ced00381aa4'] = 'HTML';
$_MODULE['<{themeconfigurator}prestashop>items_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{themeconfigurator}prestashop>items_f453e0c33edd79653febd0b9bc8f09b3'] = 'Keine Elemente vorhanden';
$_MODULE['<{themeconfigurator}prestashop>new_ff19c966036b4a0c7350b2fc7e2861c2'] = 'Posten hinzufügen';
$_MODULE['<{themeconfigurator}prestashop>new_2c92d496fa8efe3d5b2b38c185f9b7f7'] = 'Headline im Front Office verwenden';
$_MODULE['<{themeconfigurator}prestashop>new_b9b371458ab7c314f88b81c553f6ce51'] = 'Andockpunkt (Hook)';
$_MODULE['<{themeconfigurator}prestashop>new_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Bildbreite';
$_MODULE['<{themeconfigurator}prestashop>new_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Bildhöhe';
$_MODULE['<{themeconfigurator}prestashop>new_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_07a20508306b4d6c2532e80dd38e2c7f'] = 'Das Tool ist nur für Sie als Händler sichtbar (wenn Sie gerade im Back Office angemeldet sind), nicht für Ihre Besucher.';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_402bf0c47e80d12feba49f31fdcbc11f'] = 'Farbschema';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Schriftart';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_9a2c00f5f6df185a8d7d421ee70ccddf'] = 'Schriftart Headline';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_ea3aba27f515989b46d990e95a097818'] = 'Wählen Sie eine Schriftart';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_526d688f37a86d3c3f27d0c5016eb71d'] = 'Reset';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';


return $_MODULE;
