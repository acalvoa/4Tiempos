<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksocial}prestashop>blocksocial_3c3fcc2aa9705117ce4b589ed5a72853'] = 'Блок соц. сетей';
$_MODULE['<{blocksocial}prestashop>blocksocial_d918f99442796e88b6fe5ad32c217f76'] = 'Подпишитесь на наши обновления';


return $_MODULE;
