<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productscategory}prestashop>productscategory_4aae87211f77aada2c87907121576cfe'] = 'другие товары из этого раздела:';


return $_MODULE;
