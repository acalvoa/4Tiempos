<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockspecials}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Блок скидки';
$_MODULE['<{blockspecials}prestashop>blockspecials_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Показать блок даже если продукты доступны.';
$_MODULE['<{blockspecials}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Все скидки';


return $_MODULE;
