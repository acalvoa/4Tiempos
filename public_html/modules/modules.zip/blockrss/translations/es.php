<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockrss}prestashop>blockrss_2516c13a12d3dbaf4efa88d9fce2e7da'] = 'Bloque fuentes RSS';
$_MODULE['<{blockrss}prestashop>blockrss_4bb9f05422c5afbb84ed1eeb39beb8c6'] = 'Añadir un bloque que muestra un canal RSS.';
$_MODULE['<{blockrss}prestashop>blockrss_9680162225162baf2a085dfdc2814deb'] = 'fuentes RSS';
$_MODULE['<{blockrss}prestashop>blockrss_6706b6d8ba45cc4f0eda0506ba1dc3c8'] = 'URL de fuente incorrecta';
$_MODULE['<{blockrss}prestashop>blockrss_36ed65ce17306e812fd68d9f634c0c57'] = 'Título incorrecto';
$_MODULE['<{blockrss}prestashop>blockrss_1b3d34e25aef32a3c8daddfff856577f'] = 'Número de fuentes incorrecto';
$_MODULE['<{blockrss}prestashop>blockrss_549a15a569b4e5e250275db17712cd91'] = 'Ha seleccionado una URL del feed de su propio sitio web. Por favor elija otra URL.';
$_MODULE['<{blockrss}prestashop>blockrss_bef637cd0e222a8b56676cb64ce75258'] = 'El feed es inalcanzable. Seleccione otro';
$_MODULE['<{blockrss}prestashop>blockrss_1844ef1bfaa030dc8423c4645a43525c'] = 'Feed inválido';
$_MODULE['<{blockrss}prestashop>blockrss_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{blockrss}prestashop>blockrss_0a1c629f0e86804a9e165f4b1ee399b7'] = 'Error: RSS feed en "blockrss" módulo: %s';
$_MODULE['<{blockrss}prestashop>blockrss_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockrss}prestashop>blockrss_b22c8f9ad7db023c548c3b8e846cb169'] = 'Título del bloque';
$_MODULE['<{blockrss}prestashop>blockrss_5a33009bfebd22448e4265f65f8a7d98'] = 'Crear un título para el bloque (por defecto: \'feed RSS\').';
$_MODULE['<{blockrss}prestashop>blockrss_402d00ca8e4f0fff26fc24ee9ab8e82b'] = 'Añadir URL de la fuente';
$_MODULE['<{blockrss}prestashop>blockrss_3117d1276345461366a62c6950c186ed'] = 'Agregue la dirección URL de la fuente que desea utilizar (por ejemplo: http://news.google.com/?output=rss).';
$_MODULE['<{blockrss}prestashop>blockrss_ff9aa540e20285875ac8b190a3cb7ccf'] = 'Número de hilos mostrados';
$_MODULE['<{blockrss}prestashop>blockrss_0b4c4685f03f258492af3705a03b619b'] = 'Número de hilos que se muestran en el bloque (valor por defecto: 5).';
$_MODULE['<{blockrss}prestashop>blockrss_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockrss}prestashop>blockrss_10fd25dcd3353c0ba3731d4a23657f2e'] = 'No se han añadido fuentes RSS';


return $_MODULE;
