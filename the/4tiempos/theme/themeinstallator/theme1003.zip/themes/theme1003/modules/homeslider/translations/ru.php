<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{homeslider}prestashop>homeslider_693b83f5eca43e2bb1675287c37ce9e2'] = 'Слайдшоу для Вашей домашней страницы';
$_MODULE['<{homeslider}prestashop>homeslider_c17aed434289cedd02618451e12c8da6'] = 'Добавляет слайдшоу на домашнюю страницу.';
$_MODULE['<{homeslider}prestashop>homeslider_3f80dc2cdd06939d4f5514362067cd86'] = 'Недопустимое значение';
$_MODULE['<{homeslider}prestashop>homeslider_a6abafe564d3940cc36ee43e2f09400b'] = 'Недопустимый слайд';
$_MODULE['<{homeslider}prestashop>homeslider_76ad3ac84a702b0497cd6be8e8886d34'] = 'Недопустимый id_slide';
$_MODULE['<{homeslider}prestashop>homeslider_14f09fd0804a8f1cd0eb757125fc9c28'] = 'Заголовок слишком длинный';
$_MODULE['<{homeslider}prestashop>homeslider_39fc40a0ebcbfcae901d20ab8980f188'] = 'Легенда слишком длинная';
$_MODULE['<{homeslider}prestashop>homeslider_4477f672766f6f255f760649af8bd92a'] = 'URL слишком длинный';
$_MODULE['<{homeslider}prestashop>homeslider_62239300ba982b06ab0f1aa7100ad297'] = 'Описание слишком длинное';
$_MODULE['<{homeslider}prestashop>homeslider_980f56796b8bf9d607283de9815fe217'] = 'Формат URL не правилен';
$_MODULE['<{homeslider}prestashop>homeslider_349097dadf7e6b01dd2af601d54fd59a'] = 'Заголовок не установлен';
$_MODULE['<{homeslider}prestashop>homeslider_ab53605e4a73424d186afccef7b4bc03'] = 'Легенда не установлена';
$_MODULE['<{homeslider}prestashop>homeslider_0f059227d0a750ce652337d911879671'] = 'URL не установлен';
$_MODULE['<{homeslider}prestashop>homeslider_8cf45ba354f4725ec8a0d31164910895'] = 'Изображение не установлено';
$_MODULE['<{homeslider}prestashop>homeslider_7f82c65d548588c8d5412463c182e450'] = 'Конфигурация не может быть обновлена';
$_MODULE['<{homeslider}prestashop>homeslider_7cc92687130ea12abb80556681538001'] = 'При загрузке картинки произошла ошибка';
$_MODULE['<{homeslider}prestashop>homeslider_cdf841e01e10cae6355f72e6838808eb'] = 'Слайд не может быть добавлен';
$_MODULE['<{homeslider}prestashop>homeslider_eb28485b92fbf9201918698245ec6430'] = 'Слайд не может быть обновлен';
$_MODULE['<{homeslider}prestashop>homeslider_9b27e12d584b3438e811533b32e026e8'] = 'Легенда';
$_MODULE['<{homeslider}prestashop>homeslider_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Описание';
$_MODULE['<{homeslider}prestashop>homeslider_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Активен';
$_MODULE['<{homeslider}prestashop>list_7dce122004969d56ae2e0245cb754d35'] = 'Редактировать';


return $_MODULE;
