<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockspecials}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Bloque promociones especiales';
$_MODULE['<{blockspecials}prestashop>blockspecials_f5bae06098deb9298cb9ceca89171944'] = 'Añadir un bloque para mostrar los descuentos actuales en sus productos.';
$_MODULE['<{blockspecials}prestashop>blockspecials_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Mostrar este bloque aunque no haya productos disponibles.';
$_MODULE['<{blockspecials}prestashop>blockspecials_61465481ac2491b37e4517960bbd4a14'] = 'Número de archivos almacenados en caché';
$_MODULE['<{blockspecials}prestashop>blockspecials_e80a11f1704b88ad50f8fc6ce0f43525'] = 'Las ofertas serán mostradas aleatoriamente en la parte pública, pero si tiene bastantes recursos, es recomendable almacenar los resultados en la caché. La caché será borrada todos los días. 0 deshabilita la caché.';
$_MODULE['<{blockspecials}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Promociones especiales';
$_MODULE['<{blockspecials}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Todas los promociones especiales';
$_MODULE['<{blockspecials}prestashop>blockspecials_3c9f5a6dc6585f75042bd4242c020081'] = 'No hay promociones especiales en este momento.';


return $_MODULE;
